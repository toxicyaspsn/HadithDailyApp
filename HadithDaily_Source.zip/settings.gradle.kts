rootProject.name = "HadithDaily"
include(":app")