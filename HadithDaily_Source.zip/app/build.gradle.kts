plugins { id("com.android.application") }
android { namespace="com.example.hadithdaily" compileSdk=34 defaultConfig { applicationId="com.example.hadithdaily" minSdk=24 targetSdk=34 versionCode=1 versionName="1.0" } }
