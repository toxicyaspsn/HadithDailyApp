package com.example.hadithdaily
class MainActivity {}
